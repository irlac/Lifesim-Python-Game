"""Lifesim by Camden Richter"""

import time
import datetime
import pickle


"""Variables"""


now_date = datetime.datetime.date
now_time = datetime.datetime.time
cardPin = 0000


"""Classes"""


class Wallet:
    def __init__(self):
        """Wallet"""
    wallet = 0


class Bank(object):
    """Bank"""


class Savings(Bank):
    def __init__(self):
        """Savings"""
    sav_balance = 0


class Chequing(Bank):
    def __init__(self):
        """Chequing"""
    cheq_balance = 0


class Credit(Bank):
    def __init__(self):
        """Credit"""
    cred_balance = 0


"""Function Definitions"""


def withdraw():
    wd_amount = int(input("How much do you want to withdraw? "))
    if wd_amount % 20 == 0:
        acct_choose = input("From which account? [Savings/Chequing/Credit]: ")
        if acct_choose == 'Savings':
            print('Withdrawing...')
            Savings.sav_balance = Savings.sav_balance - wd_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
        if acct_choose == 'Chequing':
            print('Withdrawing...')
            Chequing.cheq_balance = Chequing.cheq_balance - wd_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
        if acct_choose == 'Credit':
            print('Withdrawing...')
            Credit.cred_balance = Credit.cred_balance - wd_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
    else:
            print("Withdrawal amounts must be multiples of 20.")
            withdraw()


def deposit():
    dp_amount = int(input("How much do you want to deposit? "))
    if dp_amount <= Wallet.wallet:
        acct_choose = input("To which account? [Savings/Chequing/Credit]: ")
        if acct_choose == 'Savings':
            print('Depositing...')
            Savings.sav_balance = Savings.sav_balance + dp_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
        if acct_choose == 'Chequing':
            print('Depositing...')
            Chequing.cheq_balance = Chequing.cheq_balance + dp_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
        if acct_choose == 'Credit':
            print('Depositing...')
            Credit.cred_balance = Credit.cred_balance + dp_amount
            time.sleep(3)
            print()
            print('Done.')
            machine_leave()
    else:
        print("You don't have enough in your wallet to deposit that much.")
        print("You only have ${0} in your wallet".format(Wallet.wallet))
        deposit()


def transfer():
    print('In Development')


def open_acct():
    print('In Development')


def clost_acct():
    print('In Development')


def balance():
    print('Your Savings account has ${0} in it.'.format(Savings.sav_balance))
    print('Your Chequing account has ${0} in it.'.format(Chequing.cheq_balance))
    print('Your Credit account has ${0} in it.'.format(Credit.cred_balance))
    print('You have ${0} in your wallet.'.format(Wallet.wallet))


def payment():
            Wallet.wallet = Wallet.wallet + 100
            print()
            print('Paid $100.')
            print()
            work()


def machine_menu():
    print()
    print('Available functions:')
    print()
    print('Withdraw')
    print('Deposit')
    print('Balance')
    print('Other')
    print()
    func_choose = input('Please enter your desired function: ')
    if func_choose == 'Withdraw' or func_choose == 'withdraw':
        withdraw()
    elif func_choose == 'Deposit' or func_choose == 'deposit':
        deposit()
    elif func_choose == 'Balance' or func_choose == 'balance':
        balance()
    elif func_choose == 'Other' or func_choose == 'other':
        machine_menu2()
    else:
        print('That is not an option.')
        input()
        machine_menu()


def machine_menu2():
    print('Available functions:')
    print()
    print('Open Account')
    print('Close Account')
    print('Transfer')
    print('Back')
    print()
    func_choose = input('Please enter your desired function: ')
    if func_choose == 'Open Account' or func_choose == 'open account':
        open_acct()
    elif func_choose == 'Close Account' or func_choose == 'close account':
        clost_acct()
    elif func_choose == 'Transfer' or func_choose == 'transfer':
        transfer()
    elif func_choose == 'Back' or func_choose == 'back':
        machine_menu()
    else:
        print('That is not an option.')
        input()
        machine_menu2()


def machine_leave():
    print()
    leave = input("Do you want to do any other banking? [Y/N]: ")
    if leave == 'Y' or leave == 'y':
        machine_menu()
    elif leave == 'N' or leave == 'n':
        done()


def pin_menu():
    pin = input("Please enter your card's PIN: ")
    if int(pin) == cardPin:
        machine_menu()
    else:
        print()
        print('Incorrect PIN')
        forgot_pin = input('Forgot your PIN? [Y/N]: ')
        if forgot_pin == 'Y' or forgot_pin == 'y':
            open_acct()
        else:
            pin_menu()


def card_insert():
    print("Please insert your card")
    print()
    insert_card = input("Insert? [Y/N]: ")
    if insert_card == 'Y' or insert_card == 'y':
        print()
        print('Inserting card...')
        time.sleep(3)
        print()
        pin_menu()
    elif insert_card == 'N' or 'No':
        done()
    else:
        card_insert()


def machine_load():
    print("Lifesim Bank ATM Machine")
    print()
    card_insert()


def done():
    print()
    print("Thank you for banking with us. Have a nice day.")
    input()
    home()


def home():
    print("Places available")
    print()
    print('Bank')
    print('Work')
    print('Coffee Shop')
    print()
    print('Quit')
    print()
    go_to = input('Where would you like to go? ')
    if go_to == 'Bank' or go_to == 'bank':
        print()
        machine_load()
    elif go_to == 'Work' or go_to == 'work':
        work()
    elif go_to == 'Coffee Shop' or go_to == 'coffee shop' or go_to == 'Coffee shop':
        """GO TO STARBUCKS"""
    elif go_to == 'Quit' or go_to == 'quit':
        save_or_no = input('Save? [Y/N]: ')
        if save_or_no == 'Y' or save_or_no == 'y':
            with open('save.dat', 'wb') as f:
                pickle.dump([cardPin, Savings.sav_balance, Chequing.cheq_balance, Credit.cred_balance], f, protocol=2)
            exit()
        elif save_or_no == 'N' or save_or_no == 'n':
            exit()


def start():
    global cardPin
    print('Welcome')
    print()
    print('Important Notes: You must go home to save and quit, and you can only check your wallet balance at the bank.')
    print()
    game_open = input('Have you played before? [Y/N]: ')
    print()
    if game_open == "Y" or game_open == 'y':
        game_load = input('Have you previously saved? [Y/N]: ')
        print()
        if game_load == 'Y' or game_load == 'y':
            with open('save.dat', 'rb') as f:
                cardPin, Savings.sav_balance, Chequing.cheq_balance, Credit.cred_balance = pickle.load(f)
        elif game_load == 'N' or game_load == 'n':
            home()
    elif game_open == 'N' or game_open == 'n':
        home()


def work():
    work_choose = input("Work? [Y/N]: ")
    if work_choose == 'Y' or work_choose == 'y':
        print('Working...')
        time.sleep(10)
        payment()
    elif work_choose == 'N' or work_choose == 'n':
        home()


"""Launch Command"""
start()
